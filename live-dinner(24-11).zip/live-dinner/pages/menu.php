	<?php
 $con=new mysqli('localhost','root','','db_live_dinner1') or die("Unable to connect");
	$query="SELECT DISTINCT package_category FROM tbl_package;";
  $result=mysqli_query($con,$query);
   if(isset($_GET['cat']))
{
$category=$_GET['cat'];
}
else
{
	$category="all";
}
if($category == "all")
{
$query1="SELECT * FROM tbl_package";
$result1=mysqli_query($con,$query1);
}
else{
	$query1="SELECT * FROM tbl_package where package_category = '$category'";
$result1=mysqli_query($con,$query1);
}

  ?>
<div class="menu-box" id="menu"> 
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<div class="heading-title text-center">
						<h2>Special Menu</h2>
						<p>Lorem Ipsum is simply dummy text of the printing and typesetting</p>
					</div>
				</div>
			</div>
			
			<div class="row inner-menu-box">
				<div class="col-3">
				<div class="nav flex-column nav-pills" id=""  role="tablist" aria-orientation="vertical">
					<a class="nav-link <?php if($category == "all"){echo 'active';}?>" id="link" href="menu.php?cat=all" role="tab" aria-controls="v-pills-home" aria-selected="true">All</a>
				<?php
			foreach($result as $resultSingle)
			{
			?>
					
						<a class="nav-link <?php if($category == $resultSingle['package_category']){echo 'active';}?>" id="link" href="menu.php?cat=<?php echo $resultSingle['package_category'];?>" role="tab" aria-controls="v-pills-home" aria-selected="true"><?php echo $resultSingle['package_category'];?></a>
					
					<?php
			}
					?>
					</div>
					</div>	
				<div class="col-9">
					<div class="tab-content" id="v-pills-tabContent">
						<div class="tab-pane fade show active" id="result" role="tabpanel" aria-labelledby="v-pills-home-tab">	
<div class="row">
<?php
foreach($result1 as $resultSingle1)
{
?>

<div class="col-lg-4 col-md-6 special-grid dinner">
									<div class="gallery-single fix">
										<img src="../images/<?php echo $resultSingle1['package_image'];?>" class="img-fluid" alt="Image">
										<div class="why-text">
											<h4><?php echo $resultSingle1['package_title'];?></h4>
											<p>Sed id magna vitae eros sagittis euismod.</p>
											<h5><?php echo $resultSingle1['package_price'];?></h5>
										</div>
									</div>
								</div>
								<?php
}
								?>		
							</div>
						</div>	
					</div>
				</div>	
			</div>
		</div>
	</div>
