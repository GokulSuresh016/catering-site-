<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<?php
 $con=new mysqli('localhost','root','','db_live_dinner1') or die("Unable to connect");
	$query="SELECT * FROM tbl_contact;";
  $result=mysqli_query($con,$query);
  if(isset($_POST['contact_submit']))
  {
	  $name= $_POST['name'];
	   $email=$_POST['email'];
	   $phone=$_POST['phone'];
	   $message=$_POST['message'];
	  $sql="insert into  tbl_enquiry(enquiry_name,enquiry_email,enquiry_phone,enquiry_meassage) values ('$name','$email','$phone','$message')";
	  $insert=mysqli_query($con,$sql);
	  if($insert)
	  {
		  echo ' <script> swal("Success!", "Submited Successfully!", "success").then(function(){window.location="index.php"}); </script>';
	  }
	  else
	  {
		  echo ' <script> swal("Warning!", "Try Again!", "warning").then(function(){window.location="contact.php"}); </script>';
	  }
  }
  ?>
<br>	
	<div class="contact-imfo-box">
		<div class="container">
			<div class="row">
			<?php
			foreach($result as $resultSingle)
			{
			?>
				<div class="col-md-4 arrow-right">
					<i class="fa fa-volume-control-phone"></i>
					<div class="overflow-hidden">
						<h4>Phone</h4>
						<p class="lead">
							<?php echo $resultSingle['contact_phone'];?>
						</p>
					</div>
				</div>
				<div class="col-md-4 arrow-right">
					<i class="fa fa-envelope"></i>
					<div class="overflow-hidden">
						<h4>Email</h4>
						<p class="lead">
							<?php echo $resultSingle['contact_email'];?>
						</p>
					</div>
				</div>
				<div class="col-md-4">
					<i class="fa fa-map-marker"></i>
					<div class="overflow-hidden">
						<h4>Location</h4>
						<p class="lead">
							<?php echo $resultSingle['contact_location'];?>
						</p>
					</div>
				</div>
				<?php
			}
				?>
				
			</div>
		</div>
	</div>
	<br>
<!-- Start Contact -->
	<div class="contact-box">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<div class="heading-title text-center">
						<h2>Contact</h2>
						<p>Lorem Ipsum is simply dummy text of the printing and typesetting</p>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-lg-12">
					<form method="POST" action="">
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<input type="text" class="form-control" id="name" name="name" placeholder="Your Name" required data-error="Please enter your name">
									<div class="help-block with-errors"></div>
								</div>                                 
							</div>
							<div class="col-md-12">
								<div class="form-group">
									<input type="text" placeholder="Your Email" id="email" class="form-control" name="email" required data-error="Please enter your email">
									<div class="help-block with-errors"></div>
								</div> 
							</div>
								<div class="col-md-12">
								<div class="form-group">
									<input type="text" placeholder="Your Phone" id="phone" class="form-control" name="phone" required data-error="Please enter your email">
									<div class="help-block with-errors"></div>
								</div> 
									</div>
											<div class="col-md-12">
								<div class="form-group"> 
									<textarea class="form-control" id="message" name="message" placeholder="Your Message" rows="4" data-error="Write your message" required></textarea>
									<div class="help-block with-errors"></div>
								</div>
								<div class="submit-button text-center">
									<button class="btn btn-common" id="contact_submit" name="contact_submit" type="submit">Send Message</button>
									<div id="msgSubmit" class="h3 text-center hidden"></div> 
									<div class="clearfix"></div> 
								</div>
							</div>
						</div>            
					</form>
				</div>
			</div>
		</div>
	</div>
	<div class="map-full"></div>
