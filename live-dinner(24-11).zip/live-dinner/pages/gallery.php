<?php
 $con=new mysqli('localhost','root','','db_live_dinner1') or die("Unable to connect");
 if(isset($_GET['page'])){
	 $page=$_GET['page'];
 }
 else
 {
	 $page=1;
 }
 $limit=2;
 $start=($page-1)*$limit;
 $query="SELECT * FROM tbl_gallery LIMIT $start,$limit";
  $result=mysqli_query($con,$query);
?>
	<!-- Start Gallery -->
	<div class="gallery-box">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<div class="heading-title text-center">
						<h2>Gallery</h2>
						<p>Lorem Ipsum is simply dummy text of the printing and typesetting</p>
					</div>
				</div>
			</div>
			<div class="tz-gallery">
				<div class="row">
				<?php
				foreach($result as $resultSingle)
				{
				?>
					<div class="col-sm-6 col-md-4 col-lg-4">
						<a class="lightbox" href="../images/<?php echo $resultSingle['gallery_image'];?>">
							<img class="img-fluid" src="../images/<?php echo $resultSingle['gallery_image'];?>" alt="Gallery Images">
						</a>
					</div>
					<?php
				}
					?>
				</div>
			</div>
		</div>
	</div>
	<!-- End Gallery -->