<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<?php
 $con=new mysqli('localhost','root','','db_live_dinner1') or die("Unable to connect");
 if(isset($_POST['login_btn']))
 {
	   $uname=$_POST['login'];
	   $pass=$_POST['password'];
	$query="SELECT * FROM tbl_login_info;";
    $result=mysqli_query($con,$query);
	foreach($result as $resultSingle){
		 $resultSingle['login_username'];
		 $resultSingle['login_password'];
		
		if(($resultSingle['login_username'] == $uname && $resultSingle['login_password'] == $pass))
		{
			echo ' <script> swal("Success!", "Signed In Successfully!", "success").then(function(){window.location="admin_panel.php"}); </script>';
		}
		else
		{
			echo ' <script> swal("warning!", "Soory.. Try Again!", "warning").then(function(){window.location="login.php"}); </script>';
		}
	}
	
		}
?>
<div class="wrapper fadeInDown">x
  <div id="formContent">
    <!-- Tabs Titles -->
    <h2 class="active fa fa-user"> Sign In </h2>
    <!-- Login Form -->
    <form action="" method="POST">
      <input type="text" id="login" class="fadeIn second" name="login" placeholder="login" required data-error="Please enter your username">
      <input type="text" id="password" class="fadeIn third" name="password" placeholder="password" required data-error="Please enter your password">
      <input type="submit" name="login_btn" class="fadeIn fourth" value="Log In">
    </form>

    <!-- Remind Passowrd -->
    <div id="formFooter">
      <a class="underlineHover" href="#">Forgot Password?</a>
    </div>

  </div>
</div>