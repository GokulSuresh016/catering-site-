	<div class="about-section-box">
		<div class="container">
			<div class="row">
				<div class="col-lg-6 col-md-6 text-center">
					<div class="inner-column">
						<h1> <span>Live Dinner Restaurant</span></h1>
						<h4>Little Story</h4>
						<p>Salkara Catering Services was established in the year 2000 to meet the increasing demand of high quality and professional services in this domain by adopting best practices available in the market today, to take Kerala’s catering industry to a higher level. We believe that our most valuable asset is our people and that is why we make sure that we bring the most experienced and qualified manpower not only to meet our client's requirements, but even exceeds their expectations. A satisfied customer is the best recommendation, and word-of-mouth remains the most effective advertising.</p>
						
					</div>
				</div>
				<div class="col-lg-6 col-md-6">
					<img src="images/about-img.jpg" alt="" class="img-fluid">
				</div>
				<div class="col-md-12">
					<div class="inner-pt" style="color:red;">
						<p>Listen to the people who love you. Believe that they are worth living for even when you don't believe it. Seek out the memories depression takes away and project them into the future. Be brave; be strong; take your pills. Exercise because it's good for you even if every step weighs a thousand pounds. Eat when food itself disgusts you. Reason with yourself when you have lost your reason.</p>
					</div>
				</div>
			</div>
		</div>
	</div>