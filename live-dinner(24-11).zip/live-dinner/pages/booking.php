<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<?php
 $con=new mysqli('localhost','root','','db_live_dinner1') or die("Unable to connect");
if(isset($_POST['login_btn']))
{
	 $name=$_POST['name'];
	 $phone=$_POST['phone'];
	 $address=$_POST['address'];
	 $location=$_POST['location'];
	 $plan=$_POST['plan'];
	 $number=$_POST['number'];
	 $queryinsert="insert into tbl_booking(booking_name,booking_phone,booking_address,booking_location,booking_package,booking_nos) values ('$name','$phone','$address','$location','$plan','$number')";
	  $resultinsert=mysqli_query($con,$queryinsert);
	  if($resultinsert)
	  {
		   $id= $con->insert_id;
		  echo ' <script> swal("Success!", "Booked Successfully!", "success").then(function(){window.location="pdf.php?id='."$id".'"}); </script>';
	  }
	  else
	  {
		  echo ' <script> swal("Warning!", "Try Again", "warning").then(function(){window.location="index.php"}); </script>';
	
	  }
}
?>
<div class="wrapper fadeInDown">
 <div id="formContent">
    <!-- Tabs Titles -->
    <h2 class="active fa fa-pencil"> Make A Booking</h2>
    <!-- Login Form -->
    <form action="" method="POST">
      <input type="text" id="name" class="fadeIn second" name="name" placeholder="Name" required data-error="Please enter your name">
      <input type="text" id="phone" class="fadeIn third" name="phone" placeholder="Phone" required data-error="Please enter your phone">
	  <input type="text" id="address" class="fadeIn third" name="address" placeholder="Address" required data-error="Please enter your address">
	  <input type="text" id="location" class="fadeIn third" name="location" placeholder="Location" required data-error="Please enter your address">
	   <select name="plan" style="width:85%;margin:5px;border: 2px solid #f6f6f6;padding: 15px 32px;background-color: #f6f6f6;text-align: center;font-size: 16px;border-radius: 5px 5px 5px 5px;margin-left:32px;" id="plan" class="form-control" style="left:50px;" required data-error="Please enter your plan">
		<option value="">Select Package</option>
	   <?php
	    $query="Select * from tbl_package;";
        $result=mysqli_query($con,$query);
	   foreach($result as $resultSingle)
	   {
		   $displaycontent=implode('.',array($resultSingle['package_id'],$resultSingle['package_title']));
		   
	   ?>
			<option value="<?php echo $resultSingle['package_id'];?>"><?php echo $displaycontent ?> </option>
			<?php
	   }
			?>
											</select>
											<div id="items" name="items">
		
		</div>
		<input type="text" id="number" class="fadeIn third" name="number" placeholder="Number of Persons">
		
      <input type="submit" name="login_btn" class="fadeIn fourth" value="Submit">
    </form>
	<br>
  </div>
    </div>