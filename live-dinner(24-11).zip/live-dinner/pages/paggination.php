	<?php
 $con=new mysqli('localhost','root','','db_live_dinner1') or die("Unable to connect");
 $query="SELECT * FROM tbl_gallery;";
 $result=mysqli_query($con,$query);
 $total=mysqli_num_rows($result);
 $total=ceil($total/2);
 $num=1;
 
 ?>

<!DOCTYPE html> 
<html> 
<head> 
<style> 
.pagination { 
    display: inline-block; 
} 
.center { 
    text-align:center; 
} 
.pagination a { 
    font-weight:bold; 
    font-size:25px; 
    color: black; 
    float: left; 
    padding: 8px 16px; 
    text-decoration: none; 
    border:1px solid black; 
} 
.pagination a.active { 
    background-color:#009900; 
} 
.pagination a:hover:not(.active) { 
    background-color: #d4d5d2; 
} 
.GFG { 
    font-size:42px; 
    font-weight:bold; 
    color:#009900; 
    text-align:center; 
    margin-bottom:60px; 
} 
.peg { 
    font-size:24px; 
    font-weight:bold; 
    margin-bottom:20px; 
    text-align:center; 
} 
</style> 
</head> 
<body>  
<div class = "center"> 
  <div class="pagination"> 
    <a href="#">«</a> 
				<?php
	  while($num <= $total){
	?>
       
    <a class = "active" href="gallery.php?page=<?php echo $num ?>"><?php echo $num;?></a> 
	         <?php
		$num=$num+1;
   }
		?>
    <a href="#">»</a> 
  </div> 
</div> 
  <br>
</body> 
</html>