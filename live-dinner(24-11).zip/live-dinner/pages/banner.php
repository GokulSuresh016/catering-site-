<?php
 $con=new mysqli('localhost','root','','db_live_dinner1') or die("Unable to connect");
	$query="SELECT * FROM tbl_banner;";
  $result=mysqli_query($con,$query);
   
  ?>
<div id="slides" class="cover-slides">
		<ul class="slides-container">
		<?php
		while($row = mysqli_fetch_array($result)){
		?>
			<li class="text-left">
				<img src="../images/<?php echo $row['banner_image'];?>" alt="">
				<div class="container">
					<div class="row">
						<div class="col-md-12">
							<h1 class="m-b-20"><strong><?php echo $row['banner_heading1'];?></strong></h1>
   <p class="m-b-40"><?php echo $row['banner_heading2']; ?></p>
							
						</div>
					</div>
				</div>
			</li>
			<?php
		}
			?>
		</ul>
		<div class="slides-navigation">
			<a href="#" class="next"><i class="fa fa-angle-right" aria-hidden="true"></i></a>
			<a href="#" class="prev"><i class="fa fa-angle-left" aria-hidden="true"></i></a>
		</div>
	</div>