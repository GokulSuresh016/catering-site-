	<?php
 $con=new mysqli('localhost','root','','db_live_dinner1') or die("Unable to connect");
 $query="Select * from tbl_staff;";
 $result=mysqli_query($con,$query);
?>
	
	<!-- Start Stuff -->
	<div class="stuff-box">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<div class="heading-title text-center">
						<h2>Staff</h2>
						<p>Lorem Ipsum is simply dummy text of the printing and typesetting</p>
					</div>
				</div>
			</div>
			<div class="row">
			<?php
			foreach($result as $resultSingle)
			{
			?>
                <div class="col-md-4 col-sm-6">
                    <div class="our-team">
                        <div class="pic">
                            <img src="../images/<?php echo $resultSingle['staff_image']; ?>">
                           <!-- <ul class="social">
                                <li><a href="#" class="fa fa-facebook"></a></li>
                                <li><a href="#" class="fa fa-google-plus"></a></li>
                                <li><a href="#" class="fa fa-instagram"></a></li>
                                <li><a href="#" class="fa fa-linkedin"></a></li>
                            </ul>-->
                        </div>
                        <div class="team-content">
                            <h3 class="title"><?php echo $resultSingle['staff_name']; ?></h3>
                            <span class="post"><?php echo $resultSingle['staff_post']; ?></span>
                        </div>
                    </div>
                </div> 
<?php
			}
?>
				
            </div>
		</div>
	</div>