<?php
if(isset($_POST['update1']))//update data from model
{
	//print_r($_POST);
	$query_column1="SHOW COLUMNS FROM $table";
	$columns1=mysqli_query($con,$query_column1);
	$inc=0;
	foreach($columns1 as $columnsSingle1)
	{
	$data[$inc]=$_POST[$columnsSingle1['Field']];
	$field[$inc]=$columnsSingle1['Field'];
	$inc=$inc+1;
	}
	$i=1;
	if($i <= $inc)
	{
		 echo $update="UPDATE  $table SET $field[$i] = $data[$i] WHERE $field[0] = $data[0]";
		$resultupdate=mysqli_query($con,$update);
	
	}
		if($resultupdate)
		{
			echo "success";
		}
}

?>