<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<?php
 $con=new mysqli('localhost','root','','db_live_dinner1') or die("Unable to connect");
 $table_id;
if(isset($_GET['table']))//table selection
{
  $table=$_GET['table'];
}
else
{
	$table="tbl_booking";
}
if(isset($_POST['update1']))//update data from model
{
	//print_r($_POST);
	$query_column1="SHOW COLUMNS FROM $table";
	$columns1=mysqli_query($con,$query_column1);
	$inc=0;
	foreach($columns1 as $columnsSingle1)
	{
	$data[$inc]=$_POST[$columnsSingle1['Field']];
	$field[$inc]=$columnsSingle1['Field'];
	$inc=$inc+1;
	}
	for($i=1;$i<$inc;$i++)
	{	
		 $update="UPDATE  $table SET $field[$i] = '".$data[$i]."' WHERE $field[0] = $data[0]";
		$resultupdate=mysqli_query($con,$update);
	}
		if($resultupdate)
		{
			header("Location:../public/admin_panel.php?table=$table");
		}
}
if(isset($_GET['delete']))//delete
{
	$table=$_GET['table'];
	$delete_id=$_GET['delete'];
	$key=$_GET['table_id'];
	$query_delete="DELETE  FROM $table where $key='$delete_id'";
	$result_update=mysqli_query($con,$query_delete);
		echo '<script> swal("Success!", "Deleted successfully!", "success"));</script>';
}


if(isset($_GET['edit']))//model
{
?>
	 <div class="row data-toggle="modal" data-target="exampleModal"">
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="false">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
	  <?php
	  $query1="SELECT * FROM $table WHERE ".$_GET['table_id']." = ".$_GET['edit']."";
	$result=mysqli_query($con,$query1);
	foreach($result as $querySingle)
	{
		$query_column="SHOW COLUMNS FROM $table";
	$columns=mysqli_query($con,$query_column);
	foreach($columns as $columnsSingle)
	{
	?>
      <div class="modal-body">
	  <form action="" method="POST">
       <div class="form-group">
		 <br>
		        <label for="name"><?php echo $columnsSingle['Field'] ?></label>
                <input class="form-control"  type="text" name="<?php echo $columnsSingle['Field'];?>" value="<?php echo $querySingle[$columnsSingle['Field']]; ?>">
            </div>		
      </div>
	  <?php
	}
	}
	  ?>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal" onclick="window.location.href='admin_panel.php?table=<?php echo $table ;?>'">Close</button>
        <button name="update1" type="submit" class="btn btn-primary">Save changes</button>
      </div>
	  </form>
    </div>
  </div>
</div>
</div>
<?php
}
?>

<div class="row">
<div class="col-md-3 ftco-animate">
    				  <div id="formContent">
    <h2 class="active fa fa-user"> Admin Panel </h2>
  <p><a href="admin_panel.php?table=tbl_booking">New Booking</a></p>
  <p><a href="admin_panel.php?table=tbl_gallery">Gallery</a></p>
  <p><a href="admin_panel.php?table=tbl_staff">Staff</a></p>
  <p><a href="admin_panel.php?table=tbl_package">Menu</a></p>
  <p><a href="admin_panel.php?table=tbl_about">About</a></p>
  <p><a href="admin_panel.php?table=tbl_contact">Contact</a></p>
  <p><a href="admin_panel.php?table=tbl_reviews">Reviews</a></p>
   
<br>

  </div>
    			</div>
				<div class="col-md-7 ftco-animate"><br>
				<?php
				$sql="SHOW COLUMNS FROM $table";
				  $result=mysqli_query($con,$sql);
				?>
				
				<table border="2" cellpadding="5">
				<tr>
				<?php
				foreach($result as $resultSingle)
				{
				?>
				<td><?php echo $resultSingle['Field'];?></td>
				<?php
				}
				?>
				<td> <a href="admin_view.php?edit="><i class="fa fa-edit"></i></a></td>	
				<td> <a href="admin_view.php?delete="><i class="fa fa-remove"></i></a></td>
				</tr>
				
					<?php
				$query="select * from $table";
				$resultdata=mysqli_query($con,$query);
				foreach($resultdata as $resultdataSingle)
				{
				?>
				<tr>
				<?php
				$sql1="SHOW COLUMNS FROM $table";
				 $result2=mysqli_query($con,$sql1);
				 $increment=1;
				 foreach($result2 as $resultcolumn)
				 {
					 if($increment == 1)
					 {
						 $table_id=$resultcolumn['Field'];
					 }
					 $increment=2;
				?>
				<td><?php echo $resultdataSingle[$resultcolumn['Field']];?></td>
				<?php
				 }
				?>
				<td> <a href="admin_panel.php?table=<?php echo $table; ?>&edit=<?php echo $resultdataSingle[$table_id];?>&table_id=<?php echo $table_id;?>"><i class="fa fa-edit"></i></a></td>	
				<td> <a href="admin_panel.php?table=<?php echo $table; ?>&delete=<?php echo $resultdataSingle[$table_id];?>&table_id=<?php echo $table_id;?>"><i class="fa fa-remove"></i></a></td>
				</tr>
				<?php
				}
				?>
				
				</table>
				
				</div>
<a href="newdata.php?table=<?php echo $table;?>"><image src="../images/adddata.ICO"style="width:75px;height:100px;margin:15px;"></image>
				</div></a>
				
				 <script>
document.getElementById("cancel").onClick=function(){
	location.href="../public/index.php";
};
</script>