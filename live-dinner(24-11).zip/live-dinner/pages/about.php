<?php
 $con=new mysqli('localhost','root','','db_live_dinner1') or die("Unable to connect");
 $query="Select * from tbl_about;";
 $result=mysqli_query($con,$query);
?>

<!-- Start About -->
	<div class="about-section-box">
		<div class="container">
			<div class="row">
			<?php
			foreach($result as $resultSingle)
			{
			?>
				<div class="col-lg-6 col-md-6 col-sm-12 text-center">
					<div class="inner-column">
						<h1><span><?php echo $resultSingle['about_heading'];?></span></h1>
						<h4>Little Story</h4>
						<p><?php echo $resultSingle['about_story'];?></p>
						<p><?php echo $resultSingle['about_story'];?></p>
						
					</div>
				</div>
				<div class="col-lg-6 col-md-6 col-sm-12">
					<img src="images/about-img.jpg" alt="" class="img-fluid">
				</div>
				<?php
			}
				?>
			</div>
		</div>
	</div>
	<!-- End About -->