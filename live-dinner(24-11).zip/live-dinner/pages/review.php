<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<?php
 $con=new mysqli('localhost','root','','db_live_dinner1') or die("Unable to connect");
if(isset($_POST['review_btn']))
{
$message=$_POST['message'];
$name=$_POST['name'];
$query="INSERT INTO tbl_reviews(review_name,review_message) VALUES ('$name','$message')";
 $result=mysqli_query($con,$query);
 if($result)
 {
	 echo ' <script> swal("Success!", "Reviewed Successfully!", "success").then(function(){window.location="index.php"}); </script>';
 }
 else
 {
	 echo ' <script> swal("warning!", "Try Again!", "warning").then(function(){window.location="review.php"}); </script>';
 }
}	
?>
<div class="wrapper fadeInDown">
  <div id="formContent">
    <!-- Tabs Titles -->
    <h2 class="active fa fa-user"> Review</h2>
    <!-- Login Form -->
    <form action="" method="POST">
      <textarea id="login" class="fadeIn second" name="message" placeholder="Review"style="width:85%;height:100px;text-align:center;"></textarea>
      <input type="text" id="password" class="fadeIn third" name="name" placeholder="Name">
      <input type="submit" name="review_btn" class="fadeIn fourth" value="Post">
    </form>
    <!-- Remind Passowrd -->
  </div>
</div>