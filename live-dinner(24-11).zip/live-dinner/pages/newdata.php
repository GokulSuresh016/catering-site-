<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<?php
 $con=new mysqli('localhost','root','','db_live_dinner1') or die("Unable to connect");
$table=$_GET['table'];
$query_column="SHOW COLUMNS FROM $table";
$columns=mysqli_query($con,$query_column);
if(isset($_POST['newdata_btn']))//click the add button
{
	$inc=0;
	$data;
	$field;
	$flag=0;
	foreach($columns as $columnsSingle1)
	{
		if(strpos($columnsSingle1['Field'],'image') !== false)
		{
	$filename=$_FILES[$columnsSingle1['Field']]['name'];	
    $tempname=$_FILES[$columnsSingle1['Field']]['tmp_name'];
    $folder="../images/".$filename;
	if(move_uploaded_file($tempname,$folder))
	{
		$data[$inc]=$filename;
		$field[$inc]=$columnsSingle1['Field'];
	}
	else{
		$data[$inc]="null";
		$field[$inc]=$columnsSingle1['Field'];
	}
		}
		else{
		$data[$inc]=$_POST[$columnsSingle1['Field']];
		$field[$inc]=$columnsSingle1['Field'];
		}
		$inc=$inc+1;
	}
		for($i=1;$i<$inc;$i++)
	{	
if($flag == 0)
{
		$insert="INSERT INTO $table($field[$i]) VALUES ('".$data[$i]."')";
		$result=mysqli_query($con,$insert);
		$flag=1;
}
else{
	   $update="UPDATE  $table SET $field[$i] = '".$data[$i]."' WHERE $field[0] = $data[0]";
		$resultupdate=mysqli_query($con,$update);
}
	}
		if($resultupdate || $result)
		{
			echo '<script> swal("Success!", "Signed In Successfully!", "success").then(function(){window.location="admin_panel.php"}); </script>';
	 
}
else
{
echo '<script> swal("Warning!", "Try Again!", "warning").then(function(){window.location="admin_panel.php"}); </script>';
}	
}
?> 
<div class="wrapper fadeInDown">
 <div id="formContent">
    <!-- Tabs Titles -->
    <h2 class="active fa fa-pencil">New Data</h2>
    <!-- Login Form -->
    <form action="" method="POST" enctype="multipart/form-data">
	<?php
	foreach($columns as $columnsSingle)
	{
	?>
	
      <input type="<?php if(strpos($columnsSingle['Field'],'image') !== false){echo "file";}else{
	  echo "text";}?>" id="name" class="fadeIn second" name="<?php echo $columnsSingle['Field'];?>" placeholder="<?php echo $columnsSingle['Field'];?>" required data-error="Please enter your name">
       <?php
	}
	  ?>
      <input type="submit" name="newdata_btn" class="fadeIn fourth" value="Submit">
    </form>
	<br>
  </div>
    </div>