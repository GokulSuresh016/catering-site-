<?php
$page='review';
include"../template/header.php";
?>
<div class="all-page-title page-breadcrumb">
		<div class="container text-center">
			<div class="row">
				<div class="col-lg-12">
					<h1>Your Review</h1>
				</div>
			</div>
		</div>
	</div>
<?php
include"../pages/review.php";
include"../template/footer.php";

?>