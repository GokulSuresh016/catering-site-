<?php
$page='contact';
include"../template/header.php";
?>
<div class="all-page-title page-breadcrumb"style="height:50px;">
		<div class="container text-center">
			<div class="row">
				<div class="col-lg-12">
					<h1>Contact Us</h1>
				</div>
			</div>
		</div>
	</div>
<?php
include"../pages/contact.php";
include"../template/footer.php";
?>