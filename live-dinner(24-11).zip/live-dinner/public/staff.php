<?php
$page='pages';
include"../template/header.php";
?>
<div class="all-page-title page-breadcrumb">
		<div class="container text-center">
			<div class="row">
				<div class="col-lg-12">
					<h1>Our Staff</h1>
				</div>
			</div>
		</div>
	</div>
<?php
include"../pages/staff.php";
include"../pages/testimony.php";
include"../template/footer.php";

?>