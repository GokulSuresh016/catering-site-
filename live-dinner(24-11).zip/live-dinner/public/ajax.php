<?php
$con=new mysqli('localhost','root','','db_live_dinner1') or die("Unable to connect");
if(isset($_POST['id']))
{
	$flag=0;
	if($_POST['id'] == 'All')
	{
		$sql="select * from tbl_package";	
		$result=mysqli_query($con,$sql);
		foreach($result as $resultSingle){
		$title=$resultSingle['package_title'];
		$image=$resultSingle['package_image'];
		$items=$resultSingle['package_items'];
		$price=$resultSingle['package_price'];
		echo "<div class=row>";
		echo "<div class=col-lg-4 col-md-6 special-grid dinner>";
		echo "<div class=gallery-single fix>";
		echo "<img src=../images/$image class=img-fluid alt=Image>";
		echo "<div class=why-text>";
		echo "<h4>$title</h4>";
		echo "<p>Sed id magna vitae eros sagittis euismod.</p>";
		echo "<h5>$price</h5>";
		echo "</div>";	
		echo "</div>";
		echo "</div>";
		echo "</div>";		
	}
	}
$dept=$_POST['id'];
$sql="select * from tbl_package where package_category='$dept'";	
$result=mysqli_query($con,$sql);
	foreach($result as $resultSingle){
		$title=$resultSingle['package_title'];
		$image=$resultSingle['package_image'];
		$items=$resultSingle['package_items'];
		$price=$resultSingle['package_price'];
		echo "<div class=row>";
		echo "<div class=col-lg-4 col-md-6 special-grid dinner>";
		echo "<div class=gallery-single fix>";
		echo "<img src=../images/$image class=img-fluid alt=Image>";
		echo "<div class=why-text>";
		echo "<h4>$title</h4>";
		echo "<p>Sed id magna vitae eros sagittis euismod.</p>";
		echo "<h5>$price</h5>";
		echo "</div>";	
		echo "</div>";
		echo "</div>";
		echo "</div>";		
	}
}
?>