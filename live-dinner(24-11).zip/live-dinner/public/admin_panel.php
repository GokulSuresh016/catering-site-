<?php
include"../template/header.php";
?>
<div class="all-page-title page-breadcrumb">
		<div class="container text-center">
			<div class="row">
				<div class="col-lg-12">
					<h1>Admin Panel</h1>
				</div>
			</div>
		</div>
	</div>
<?php
include"../pages/admin_panel.php";
include"../template/footer.php";
if(isset($_GET['edit']))
{
?>
<script>
$(window).on('load',function(){
        $('#exampleModal').modal('show');
    });
	 </script>
<?php
}
?>