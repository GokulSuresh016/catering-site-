<?php
include"../template/header.php";
?>
<div class="all-page-title page-breadcrumb">
		<div class="container text-center">
			<div class="row">
				<div class="col-lg-12">
					<h1>Log In </h1>
				</div>
			</div>
		</div>
	</div>
<?php
include"../pages/account_login.php";
include"../template/footer.php";
?>