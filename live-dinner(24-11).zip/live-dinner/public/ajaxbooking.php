<?php
$con=new mysqli('localhost','root','','db_live_dinner1') or die("Unable to connect");
if(isset($_POST['plan']))
{
	$item=$_POST['plan'];
	 $query="Select * from tbl_package Where package_id=$item;";
 $result=mysqli_query($con,$query);
 foreach($result as $resultSingle)
 {
	 $items=$resultSingle['package_items'];
	echo "<input type='text'  class='fadeIn third' placeholder='$items' readonly='readonly'>";
 }
}
?>