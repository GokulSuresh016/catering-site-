<?php
$page='menu';
include"../template/header.php";
?>
<div class="all-page-title page-breadcrumb">
		<div class="container text-center">
			<div class="row">
				<div class="col-lg-12">
					<h1>Special Menu</h1>
				</div>
			</div>
		</div>
	</div>
<?php
include"../pages/menu.php";
include"../template/footer.php";
?>
