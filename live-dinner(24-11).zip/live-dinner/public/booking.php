<?php
$page='booking';
include"../template/header.php";
?>
<div class="all-page-title page-breadcrumb">
		<div class="container text-center">
			<div class="row">
				<div class="col-lg-12">
					<h1>Welcome To Booking</h1>
				</div>
			</div>
		</div>
	</div>
<?php
include"../pages/booking.php";
include"../template/footer.php";
?>
<script>
$(document).ready(function(){
	$('#plan').change(function(){
	var datainput=this.value;
	alert(datainput);
		$.ajax({
		method:"POST",
		url:"ajaxbooking.php",
		data:'plan='+datainput,
		dataType:"html",
		success:function(data){
			$('#items').html(data);
		}
	})

});
});
</script>