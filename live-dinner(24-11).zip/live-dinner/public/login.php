<?php
$page='login';
include"../template/header.php";	
include"../pages/login.php";
include"../template/footer.php";
?>